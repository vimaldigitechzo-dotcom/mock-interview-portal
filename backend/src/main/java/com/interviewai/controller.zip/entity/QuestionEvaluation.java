package com.interviewai.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "question_evaluations")
public class QuestionEvaluation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id", nullable = false)
    private SessionQuestion question;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "session_id", nullable = false)
    private InterviewSession session;

    @Column(name = "correctness_score")
    private Integer correctnessScore;

    @Column(name = "completeness_score")
    private Integer completenessScore;

    @Column(name = "clarity_score")
    private Integer clarityScore;

    @Column(name = "overall_score")
    private Integer overallScore;

    @Column(name = "mark")
    private Double mark;

    @Column(columnDefinition = "TEXT")
    private String feedback;

    @Column(columnDefinition = "TEXT")
    private String strengths;

    @Column(columnDefinition = "TEXT")
    private String improvements;

    @Column(name = "ideal_answer", columnDefinition = "TEXT")
    private String idealAnswer;

    @Column(name = "evaluated_at")
    private LocalDateTime evaluatedAt = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public SessionQuestion getQuestion() { return question; }
    public void setQuestion(SessionQuestion question) { this.question = question; }
    public InterviewSession getSession() { return session; }
    public void setSession(InterviewSession session) { this.session = session; }
    public Integer getCorrectnessScore() { return correctnessScore; }
    public void setCorrectnessScore(Integer value) { this.correctnessScore = value; }
    public Integer getCompletenessScore() { return completenessScore; }
    public void setCompletenessScore(Integer value) { this.completenessScore = value; }
    public Integer getClarityScore() { return clarityScore; }
    public void setClarityScore(Integer value) { this.clarityScore = value; }
    public Integer getOverallScore() { return overallScore; }
    public void setOverallScore(Integer value) { this.overallScore = value; }
    public Double getMark() { return mark; }
    public void setMark(Double value) { this.mark = value; }
    public String getFeedback() { return feedback; }
    public void setFeedback(String value) { this.feedback = value; }
    public String getStrengths() { return strengths; }
    public void setStrengths(String value) { this.strengths = value; }
    public String getImprovements() { return improvements; }
    public void setImprovements(String value) { this.improvements = value; }
    public String getIdealAnswer() { return idealAnswer; }
    public void setIdealAnswer(String value) { this.idealAnswer = value; }
    public LocalDateTime getEvaluatedAt() { return evaluatedAt; }
    public void setEvaluatedAt(LocalDateTime value) { this.evaluatedAt = value; }
}
