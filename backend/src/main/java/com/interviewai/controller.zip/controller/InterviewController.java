package com.interviewai.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.interviewai.entity.InterviewSession;
import com.interviewai.entity.QuestionEvaluation;
import com.interviewai.entity.Recommendation;
import com.interviewai.entity.SessionQuestion;
import com.interviewai.entity.TopicStat;
import com.interviewai.entity.User;
import com.interviewai.repository.InterviewSessionRepository;
import com.interviewai.repository.QuestionEvaluationRepository;
import com.interviewai.repository.RecommendationRepository;
import com.interviewai.repository.SessionQuestionRepository;
import com.interviewai.repository.TopicStatRepository;
import com.interviewai.repository.UserRepository;
import com.interviewai.service.AiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/interview")
public class InterviewController {
    @Autowired private InterviewSessionRepository sessionRepo;
    @Autowired private SessionQuestionRepository questionRepo;
    @Autowired private QuestionEvaluationRepository evalRepo;
    @Autowired private TopicStatRepository topicStatRepo;
    @Autowired private RecommendationRepository recommendationRepo;
    @Autowired private UserRepository userRepo;
    @Autowired private AiService aiService;
    @Autowired private ObjectMapper objectMapper;

    @GetMapping("/topics")
    public ResponseEntity<?> getTopics() {
        return ResponseEntity.ok(List.of(
                Map.of("id", "dsa", "name", "Data Structures & Algorithms", "description", "Arrays, trees, graphs, sorting, dynamic programming"),
                Map.of("id", "system-design", "name", "System Design", "description", "Scalability, databases, caching, load balancing"),
                Map.of("id", "behavioral", "name", "Behavioral", "description", "Leadership, teamwork, conflict resolution"),
                Map.of("id", "database", "name", "Database Design", "description", "SQL, normalization, indexing, transactions"),
                Map.of("id", "oop", "name", "Object-Oriented Programming", "description", "SOLID principles, design patterns, polymorphism"),
                Map.of("id", "web-dev", "name", "Web Development", "description", "Frontend, backend, APIs, security"),
                Map.of("id", "devops", "name", "DevOps & Cloud", "description", "CI/CD, Docker, Kubernetes, AWS/GCP"),
                Map.of("id", "networking", "name", "Computer Networks", "description", "HTTP, TCP/IP, DNS, security protocols"),
                Map.of("id", "operating-systems", "name", "Operating Systems", "description", "Processes, threads, memory management"),
                Map.of("id", "ai-ml", "name", "AI & Machine Learning", "description", "Neural networks, algorithms, data pipelines")
        ));
    }

    @PostMapping("/start")
    public ResponseEntity<?> startSession(@RequestBody Map<String, Object> request, Authentication authentication) {
        User user = userRepo.findById(getUserId(authentication)).orElseThrow();
        String topic = String.valueOf(request.getOrDefault("topic", "dsa"));
        String difficulty = String.valueOf(request.getOrDefault("difficulty", "Medium"));
        String questionType = String.valueOf(request.getOrDefault("questionType", "MIXED")).toUpperCase();
        if (!List.of("MCQ", "WRITTEN", "MIXED").contains(questionType)) questionType = "MIXED";
        int count = Integer.parseInt(String.valueOf(request.getOrDefault("numQuestions", 5)));

        InterviewSession session = new InterviewSession();
        session.setUser(user);
        session.setTopic(topic);
        session.setDifficulty(difficulty);
        session.setQuestionType(questionType);
        session.setTotalQuestions(count);
        session.setAnsweredQuestions(0);
        session.setOverallScore(0.0);
        session.setStatus("active");
        session.setStartedAt(LocalDateTime.now());
        session.setCreatedAt(LocalDateTime.now());
        session = sessionRepo.save(session);

        List<Map<String, Object>> generated = aiService.generateQuestions(topic, difficulty, count, questionType);
        List<Map<String, Object>> questions = new ArrayList<>();

        for (int index = 0; index < generated.size(); index++) {
            Map<String, Object> source = generated.get(index);
            SessionQuestion question = new SessionQuestion();
            question.setSession(session);
            question.setQuestionNumber(index + 1);
            question.setQuestionText(String.valueOf(source.getOrDefault("question", "")));
            question.setQuestionDifficulty(difficulty);
            question.setQuestionType(String.valueOf(source.getOrDefault("questionType", "WRITTEN")));
            question.setCorrectOption((String) source.get("correctOption"));
            question.setExplanation((String) source.get("explanation"));
            question.setOptionsJson(writeOptions(source.get("options")));
            question.setSubmitted("pending");
            question.setCreatedAt(LocalDateTime.now());
            question = questionRepo.save(question);

            Map<String, Object> output = new HashMap<>();
            output.put("id", question.getId());
            output.put("questionNumber", question.getQuestionNumber());
            output.put("questionText", question.getQuestionText());
            output.put("questionType", question.getQuestionType());
            output.put("options", parseOptions(question.getOptionsJson()));
            output.put("submitted", question.getSubmitted());
            questions.add(output);
        }

        return ResponseEntity.ok(Map.of(
                "sessionId", session.getId(),
                "questions", questions,
                "topic", topic,
                "difficulty", difficulty,
                "questionType", questionType,
                "totalQuestions", count
        ));
    }

    @GetMapping("/session/{sessionId}")
    public ResponseEntity<?> getSession(@PathVariable Long sessionId, Authentication authentication) {
        InterviewSession session = ownedSession(sessionId, authentication);
        List<SessionQuestion> stored = questionRepo.findBySessionIdOrderByQuestionNumber(sessionId);
        List<Map<String, Object>> questions = new ArrayList<>();

        for (SessionQuestion question : stored) {
            Map<String, Object> output = new HashMap<>();
            output.put("id", question.getId());
            output.put("questionNumber", question.getQuestionNumber());
            output.put("questionText", question.getQuestionText());
            output.put("questionType", question.getQuestionType() == null ? "WRITTEN" : question.getQuestionType());
            output.put("options", parseOptions(question.getOptionsJson()));
            output.put("userAnswer", question.getUserAnswer() == null ? "" : question.getUserAnswer());
            output.put("submitted", question.getSubmitted() == null ? "pending" : question.getSubmitted());

            Optional<QuestionEvaluation> evaluation = evalRepo.findByQuestionId(question.getId());
            evaluation.ifPresent(value -> output.put("evaluation", serializeEvaluation(value, question)));
            questions.add(output);
        }

        return ResponseEntity.ok(Map.of("session", serializeSession(session), "questions", questions));
    }

    @PostMapping("/submit-answer")
    public ResponseEntity<?> submitAnswer(@RequestBody Map<String, Object> request, Authentication authentication) {
        Long sessionId = Long.parseLong(String.valueOf(request.get("sessionId")));
        Long questionId = Long.parseLong(String.valueOf(request.get("questionId")));
        InterviewSession session = ownedSession(sessionId, authentication);
        SessionQuestion question = questionRepo.findById(questionId).orElseThrow();

        if (!question.getSession().getId().equals(sessionId)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Question does not belong to this session"));
        }

        String answer = String.valueOf(request.getOrDefault("answer", "")).trim();
        if (answer.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Answer is required"));
        }

        boolean mcq = "MCQ".equalsIgnoreCase(question.getQuestionType()) || request.get("selectedOption") != null;
        Map<String, Object> evaluation;

        if (mcq) {
            String selected = String.valueOf(request.getOrDefault("selectedOption", answer)).trim();
            String correct = question.getCorrectOption() == null ? "" : question.getCorrectOption().trim();
            boolean isCorrect = !correct.isBlank() && selected.equalsIgnoreCase(correct);
            int score = isCorrect ? 100 : 0;
            evaluation = new HashMap<>();
            evaluation.put("mark", isCorrect ? 1.0 : 0.0);
            evaluation.put("isCorrect", isCorrect);
            evaluation.put("correctAnswer", correct);
            evaluation.put("shortExplanation", question.getExplanation() == null ? "" : question.getExplanation());
            evaluation.put("feedback", isCorrect ? "Correct option selected." : "Incorrect option selected.");
            evaluation.put("correctnessScore", score);
            evaluation.put("completenessScore", score);
            evaluation.put("clarityScore", score);
            evaluation.put("overallScore", score);
            evaluation.put("strengths", isCorrect ? "Correct option selected." : "Review the correct option.");
            evaluation.put("improvements", isCorrect ? "" : "Review the explanation.");
            evaluation.put("idealAnswer", correct);
        } else {
            evaluation = aiService.evaluateAnswer(question.getQuestionText(), answer, session.getDifficulty(), session.getTopic());
            evaluation.put("mark", normalizeMark(evaluation.get("mark")));
        }

        question.setUserAnswer(answer);
        question.setSubmitted("submitted");
        questionRepo.save(question);

        QuestionEvaluation entity = evalRepo.findByQuestionId(questionId).orElseGet(QuestionEvaluation::new);
        entity.setQuestion(question);
        entity.setSession(session);
        entity.setMark(normalizeMark(evaluation.get("mark")));
        entity.setCorrectnessScore(asInt(evaluation.get("correctnessScore")));
        entity.setCompletenessScore(asInt(evaluation.get("completenessScore")));
        entity.setClarityScore(asInt(evaluation.get("clarityScore")));
        entity.setOverallScore(asInt(evaluation.get("overallScore")));
        entity.setFeedback(asString(evaluation.get("feedback")));
        entity.setStrengths(asString(evaluation.get("strengths")));
        entity.setImprovements(asString(evaluation.get("improvements")));
        entity.setIdealAnswer(asString(evaluation.getOrDefault("correctAnswer", evaluation.get("idealAnswer"))));
        entity.setEvaluatedAt(LocalDateTime.now());
        evalRepo.save(entity);

        List<QuestionEvaluation> allEvaluations = evalRepo.findBySessionId(sessionId);
        long answered = questionRepo.findBySessionIdOrderByQuestionNumber(sessionId).stream()
                .filter(value -> "submitted".equals(value.getSubmitted())).count();
        double percentage = allEvaluations.stream()
                .mapToDouble(value -> normalizeMark(value.getMark()) * 100.0)
                .average().orElse(0.0);
        session.setAnsweredQuestions((int) answered);
        session.setOverallScore(percentage);
        sessionRepo.save(session);

        return ResponseEntity.ok(Map.of(
                "evaluation", evaluation,
                "answeredCount", answered,
                "totalQuestions", session.getTotalQuestions(),
                "overallScore", percentage
        ));
    }

    @PostMapping("/complete/{sessionId}")
    public ResponseEntity<?> completeSession(@PathVariable Long sessionId, Authentication authentication) {
        InterviewSession session = ownedSession(sessionId, authentication);
        List<QuestionEvaluation> evaluations = evalRepo.findBySessionId(sessionId);
        double finalPercentage = evaluations.stream()
                .mapToDouble(value -> normalizeMark(value.getMark()) * 100.0)
                .average().orElse(0.0);
        session.setStatus("completed");
        session.setOverallScore(finalPercentage);
        session.setCompletedAt(LocalDateTime.now());
        sessionRepo.save(session);
        updateTopicStats(session.getUser().getId(), session.getTopic(), finalPercentage, evaluations.size());

        return ResponseEntity.ok(Map.of(
                "session", serializeSession(session),
                "finalScore", finalPercentage,
                "totalQuestions", session.getTotalQuestions()
        ));
    }

    private InterviewSession ownedSession(Long sessionId, Authentication authentication) {
        InterviewSession session = sessionRepo.findById(sessionId).orElseThrow();
        if (!session.getUser().getId().equals(getUserId(authentication))) {
            throw new org.springframework.security.access.AccessDeniedException("Access denied");
        }
        return session;
    }

    private Long getUserId(Authentication authentication) {
        return userRepo.findByEmail(authentication.getName()).orElseThrow().getId();
    }

    private double normalizeMark(Object value) {
        try {
            double mark = Double.parseDouble(String.valueOf(value));
            if (mark == 1.0 || mark == 0.5 || mark == 0.0) return mark;
            if (mark >= 80) return 1.0;
            if (mark >= 40) return 0.5;
        } catch (Exception ignored) { }
        return 0.0;
    }

    private int asInt(Object value) {
        try { return (int) Math.round(Double.parseDouble(String.valueOf(value))); }
        catch (Exception ignored) { return 0; }
    }

    private String asString(Object value) { return value == null ? "" : String.valueOf(value); }

    private String writeOptions(Object value) {
        if (value == null) return null;
        try { return objectMapper.writeValueAsString(value); }
        catch (Exception ignored) { return null; }
    }

    private List<String> parseOptions(String json) {
        if (json == null || json.isBlank()) return List.of();
        try {
            return objectMapper.readValue(json, objectMapper.getTypeFactory().constructCollectionType(List.class, String.class));
        } catch (Exception ignored) { return List.of(); }
    }

    private Map<String, Object> serializeEvaluation(QuestionEvaluation value, SessionQuestion question) {
        Map<String, Object> output = new HashMap<>();
        output.put("mark", normalizeMark(value.getMark()));
        output.put("correctnessScore", value.getCorrectnessScore());
        output.put("completenessScore", value.getCompletenessScore());
        output.put("clarityScore", value.getClarityScore());
        output.put("overallScore", value.getOverallScore());
        output.put("feedback", value.getFeedback());
        output.put("strengths", value.getStrengths());
        output.put("improvements", value.getImprovements());
        output.put("idealAnswer", value.getIdealAnswer());
        if ("MCQ".equalsIgnoreCase(question.getQuestionType())) {
            output.put("correctAnswer", question.getCorrectOption());
            output.put("shortExplanation", question.getExplanation());
        }
        return output;
    }

    private Map<String, Object> serializeSession(InterviewSession session) {
        Map<String, Object> output = new HashMap<>();
        output.put("id", session.getId());
        output.put("topic", session.getTopic());
        output.put("difficulty", session.getDifficulty());
        output.put("totalQuestions", session.getTotalQuestions());
        output.put("answeredQuestions", session.getAnsweredQuestions());
        output.put("overallScore", session.getOverallScore());
        output.put("status", session.getStatus());
        output.put("startedAt", session.getStartedAt() == null ? "" : session.getStartedAt().toString());
        output.put("completedAt", session.getCompletedAt() == null ? "" : session.getCompletedAt().toString());
        return output;
    }

    private void updateTopicStats(Long userId, String topic, double score, int count) {
        Optional<TopicStat> existing = topicStatRepo.findByUserIdAndTopic(userId, topic);
        TopicStat stat = existing.orElseGet(() -> {
            TopicStat created = new TopicStat();
            created.setUser(userRepo.findById(userId).orElseThrow());
            created.setTopic(topic);
            created.setTotalSessions(0);
            created.setTotalQuestions(0);
            created.setAverageScore(0.0);
            created.setBestScore(0.0);
            return created;
        });
        int sessions = stat.getTotalSessions() + 1;
        stat.setTotalSessions(sessions);
        stat.setTotalQuestions(stat.getTotalQuestions() + count);
        stat.setAverageScore(((stat.getAverageScore() * (sessions - 1)) + score) / sessions);
        stat.setBestScore(Math.max(stat.getBestScore(), score));
        stat.setUpdatedAt(LocalDateTime.now());
        topicStatRepo.save(stat);
    }
}
